package org.example.db;

public enum DbType {
    MYSQL,
    POSTGRES
}
